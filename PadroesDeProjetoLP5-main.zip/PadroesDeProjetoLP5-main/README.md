# PadroesDeProjetoLP5
Repositório utilizado para as atividades da Matéria de LP5
